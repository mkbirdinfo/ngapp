import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {Router} from '@angular/router';
import { from } from 'rxjs';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 private Users:any=[];
 private _router;
 private flag:boolean;
  constructor(private router:Router) {
    this._router=router;
   }

  ngOnInit() {
  }
   loginCreds=new FormGroup({
     email:new FormControl(''),
     password:new FormControl('')
   })

   OnLoginSubmit(){
  if(this.checkcreds()==1){
   // alert('You are logged in successfully');
  
  this.flag=true;
  this._router.navigate(['/list']);
  }
  else{
   // alert('wrong credentials');
    this.flag=false
  }

 

   }

   checkcreds(){
var r;
    this.Users=JSON.parse(localStorage.getItem('users'));
    for(var emp of this.Users){
      if(emp.email==this.loginCreds.value.email&&emp.Password==this.loginCreds.value.password){
      r=1;
       
      }
      else{
     r=0;
      
      }
    }
    return r;
   }


}
