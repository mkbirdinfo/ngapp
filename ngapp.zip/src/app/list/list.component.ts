import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
private Users:any=[];
  constructor(private _router:Router) {
  
   this.Users=JSON.parse(localStorage.getItem('users'));

   }

  ngOnInit() {
  }
     
  
 delete(mail:string){
  var filtered = this.Users.filter(function(value, index, arr){

    return value.email!=mail;

});
// var emp=  this.Users.find(x=>x.email==mail);
this.Users=filtered;
localStorage.setItem('users',JSON.stringify(this.Users));
this._router.navigate(['/list']);



 }

 Edit(mail:string){
   
 }




}
