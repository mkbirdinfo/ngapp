import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms'
import {Router} from '@angular/router';
import { from } from 'rxjs';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  private _router;
  constructor(private router: Router) {
   this._router=router;
   }
private Users:any=[];
  ngOnInit() {
  }
  EmployeeForm=new FormGroup({
     firstName:new FormControl(''),
     lastName:new FormControl(''),
     email:new FormControl(''),
     Password:new FormControl('')


  });

  OnSubmit(){

console.log(this.EmployeeForm.value);

  if(localStorage.getItem('users')===null){
    this.Users.push(this.EmployeeForm.value);
    localStorage.setItem('users',JSON.stringify(this.Users));
  }
  else{
  this.Users=JSON.parse(localStorage.getItem('users')) ;
  
  this.Users.push(this.EmployeeForm.value);
  localStorage.setItem('users',JSON.stringify(this.Users));
  
  }
   
 this._router.navigate(['/login']);

  }

}
